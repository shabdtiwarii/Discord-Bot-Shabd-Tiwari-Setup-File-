import discord
from discord import app_commands
from discord.ext import commands
import os
import asyncio
import google.generativeai as genai

# Configure Gemini API (User can set GEMINI_API_KEY env variable)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_API_KEY")
if GEMINI_API_KEY != "YOUR_GEMINI_API_KEY":
    genai.configure(api_key=GEMINI_API_KEY)
    gemini_model = genai.GenerativeModel('gemini-1.5-flash')
else:
    gemini_model = None

ALLOWED_ROLES = {"Administrator", "Server Manager", "Moderator"}
APPEAL_EMAIL = "contactshabdtiwari.appeals@gmail.com"

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.voice_states = True

bot = commands.Bot(command_prefix="!", intents=intents)

def has_staff_role(interaction: discord.Interaction) -> bool:
    user_roles = {role.name for role in interaction.user.roles}
    return bool(user_roles & ALLOWED_ROLES)

async def send_appeal_dm(member: discord.Member, action_type: str, reason: str, duration: str = None):
    try:
        msg = f"⚠️ **Notice:** You have been **{action_type}ed** from **{member.guild.name}**.\n"
        msg += f"📄 **Reason:** {reason}\n"
        if duration:
            msg += f"⏳ **Duration:** {duration}\n"
        msg += f"📩 **Appeal:** If you wish to appeal this decision, please contact: `{APPEAL_EMAIL}`"
        await member.send(msg)
    except Exception:
        pass

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Logged in as {bot.user}!")

# ----------------- AI CHAT & AUTO-MODERATION (ChatGPT-like in any language) -----------------
@bot.event
async def on_message(message):
    if message.author.bot:
        return

    content = message.content
    content_lower = content.lower()

    # Trigger AI response if mentioned or inside a ticket or replying directly
    is_ticket = "ticket-" in message.channel.name
    is_mentioned = bot.user.mentioned_in(message)

    if is_mentioned or is_ticket:
        # If Gemini API Key is available, use real AI
        if gemini_model:
            try:
                # Prompt tuning for server moderation and multi-language capability
                prompt = (
                    f"You are ShabdTiwari AI, an advanced, friendly, and intelligent Discord server assistant and moderator. "
                    f"You can speak and understand ANY language fluently (Hindi, English, Spanish, etc.). "
                    f"You help manage tickets, analyze rules, and chat like ChatGPT with appropriate mood. "
                    f"User message: {content}"
                )
                response = gemini_model.generate_content(prompt)
                ai_reply = response.text
                await message.reply(ai_reply)
            except Exception:
                await message.reply(f"Namaste {message.author.mention}! Main aapki baat samajh gaya hun, kripya apna sawaal poori tarah rakhein.")
        else:
            # Fallback smart reply if API key is not configured yet
            await message.reply(f"Hello {message.author.mention}! Main AI-powered bot hun. (Kripya apka GEMINI_API_KEY environment variable set karein taaki ChatGPT jaisi full intelligence mile).")

    await bot.process_commands(message)

# ----------------- AUTOMATED MULTI-LANGUAGE TICKET SYSTEM -----------------
class MultiLangTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="📩 Create Ticket / टिकट बनाएं", style=discord.ButtonStyle.primary, custom_id="create_ticket_ai")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }
        for role_name in ALLOWED_ROLES:
            role = discord.utils.get(guild.roles, name=role_name)
            if role:
                overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

        channel_name = f"ticket-{interaction.user.name}"
        existing = discord.utils.get(guild.channels, name=channel_name)
        if existing:
            await interaction.response.send_message(f"❌ Ticket already open / टिकट पहले से खुला है: {existing.mention}", ephemeral=True)
            return

        channel = await guild.create_text_channel(name=channel_name, overwrites=overwrites)
        await channel.send(
            f"Welcome {interaction.user.mention}! 🤖 Main yahan AI ticket manager hun. Aap kisi bhi bhasha (Hindi, English, etc.) me apni samasya likh sakte hain, main turant help karunga.\n"
            f"Use `/close_ticket` to close this ticket."
        )
        await interaction.response.send_message(f"✅ Ticket created: {channel.mention}", ephemeral=True)

@bot.tree.command(name="setup_ticket", description="Setup AI-powered multi-language ticket panel.")
async def setup_ticket(interaction: discord.Interaction):
    if not has_staff_role(interaction):
        await interaction.response.send_message("❌ No permission.", ephemeral=True)
        return
    embed = discord.Embed(
        title="🤖 AI-Powered Smart Support System",
        description="Click the button below to open an intelligent support ticket in any language.\nकिसी भी भाषा में स्मार्ट सहायता के लिए नीचे बटन दबाएं।",
        color=discord.Color.blue()
    )
    await interaction.channel.send(embed=embed, view=MultiLangTicketView())
    await interaction.response.send_message("✅ AI Ticket panel set up!", ephemeral=True)

@bot.tree.command(name="close_ticket", description="Close current ticket.")
async def close_ticket(interaction: discord.Interaction):
    if "ticket-" in interaction.channel.name:
        await interaction.response.send_message("🔒 Closing ticket in 5 seconds...")
        await asyncio.sleep(5)
        await interaction.channel.delete()
    else:
        await interaction.response.send_message("❌ Use inside ticket channel.", ephemeral=True)

# ----------------- VOICE CALL CHAT SYSTEM -----------------
@bot.tree.command(name="join_call", description="Join voice call and chat.")
async def join_call(interaction: discord.Interaction):
    if interaction.user.voice:
        channel = interaction.user.voice.channel
        await channel.connect()
        await interaction.response.send_message(f"🔊 Joined **{channel.name}**! Voice call me chat ke zariye baat kar sakte hain.", ephemeral=True)
    else:
        await interaction.response.send_message("❌ Pehle voice channel join karein.", ephemeral=True)

@bot.tree.command(name="leave_call", description="Leave voice call.")
async def leave_call(interaction: discord.Interaction):
    if interaction.guild.voice_client:
        await interaction.guild.voice_client.disconnect()
        await interaction.response.send_message("👋 Voice channel chhod diya.", ephemeral=True)
    else:
        await interaction.response.send_message("❌ Bot kisi call me nahi hai.", ephemeral=True)

token = os.getenv("DISCORD_BOT_TOKEN", "YOUR_DISCORD_BOT_TOKEN")
bot.run(token)
